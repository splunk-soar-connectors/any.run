"""Defines a ANY.RUN object and other helper classes."""

from collections import UserDict
import typing
import json


class UserDictJsonEncoder(json.JSONEncoder):
    """Custom json encoder for UserDict objects."""

    def default(self, o):
        if isinstance(o, UserDict):
            return o.data
        return super().default(o)


class Configuration:
    """Analysis configuration class for specifying optional parameters
    for the sandbox, where new submission analysis will be performed.

    Learn more about available parameters in the ANY.RUN Sandbox API in:
    https://any.run/api-documentation/
    """

    # pylint: disable=line-too-long
    ATTRIBUTES_STR = ["env_os", "env_version", "env_type", "env_locale", "opt_network_geo", "opt_network_residential_proxy_geo", "opt_privacy_type", "obj_ext_startfolder", "obj_ext_cmd", "obj_ext_browser", "obj_ext_useragent"]
    ATTRIBUTES_BOOL = ["opt_network_connect", "opt_network_fakenet", "opt_network_tor", "opt_network_mitm", "opt_network_residential_proxy", "opt_kernel_heavyevasion", "opt_automated_interactivity", "obj_ext_elevateprompt", "auto_confirm_uac", "run_as_root", "obj_ext_extension", "opt_privacy_hidesource"]
    ATTRIBUTES_INT = ["env_bitness", "opt_timeout"]
    OPT_NETWORK_GEO = ["fastest", "AU", "BR", "CH", "DE", "FR", "GB", "IT", "KR", "RU", "US"]
    OPT_NETWORK_RESIDENTIAL_PROXY_GEO = ["fastest", "AD", "AE", "AF", "AG", "AL", "AL", "AM", "AO", "AR", "AT", "AU", "AZ", "BA", "BB", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BN", "BO", "BR", "BS", "BT", "BW", "BY", "BZ", "CA", "CD", "CF", "CG", "CH", "CI", "CL", "CM", "CN", "CO", "CR", "CU", "CV", "CW", "CY", "CZ", "DE", "DJ", "DK", "DM", "DO", "DZ", "EC", "EE", "EG", "ES", "ET", "FI", "FJ", "FR", "GA", "GB", "GD", "GE", "GF", "GH", "GM", "GN", "GP", "GQ", "GR", "GT", "GU", "GW", "GY", "HK", "HN", "HR", "HT", "HU", "ID", "IE", "IL", "IM", "IN", "IQ", "IR", "IS", "IT", "JE", "JM", "JO", "JP", "KE", "KG", "KH", "KR", "KW", "KY", "KZ", "LA", "LB", "LC", "LK", "LR", "LS", "LT", "LU", "LV", "LY", "MA", "MD", "ME", "MG", "MK", "ML", "MM", "MN", "MO", "MQ", "MR", "MT", "MU", "MW", "MX", "MY", "MZ", "NA", "NE", "NG", "NI", "NL", "NO", "NP", "NZ", "OM", "PA", "PE", "PF", "PG", "PH", "PK", "PL", "PR", "PS", "PT", "PY", "QA", "RE", "RO", "RS", "RU", "RW", "SA", "SC", "SD", "SE", "SG", "SI", "SK", "SL", "SN", "SO", "SR", "SS", "SV", "SX", "SY", "SZ", "TD", "TG", "TH", "TJ", "TN", "TR", "TT", "TW", "TZ", "UA", "UG", "US", "UY", "UZ", "VE", "VI", "VN", "YE", "YT", "ZA", "ZM", "ZW"]
    OBJ_EXT_START_FOLDER = ["desktop", "home", "downloads", "appdata", "temp", "windows", "root"]
    # pylint: enable=line-too-long

    @classmethod
    def from_dict(cls, attr_dict: typing.Dict):
        """Creates an object from its dictionary representation."""
        if not isinstance(attr_dict, dict):
            raise ValueError(f"Expecting dictionary, got: {type(attr_dict).__name__}")
        return cls(**attr_dict)

    def __init__(self, **kwargs) -> None:
        """Initializes an ANY.RUN Sandbox API Configuration object."""
        if kwargs is None:
            raise ValueError("Expecting at least one named argument, got none")
        for attr, value in kwargs.items():
            setattr(self, attr, value)

    def __setattr__(self, attr: str, value: typing.Any) -> None:
        """Sets new attribute value, if all validation checks are successful"""
        # pylint: disable=line-too-long
        if attr not in Configuration.ATTRIBUTES_STR+Configuration.ATTRIBUTES_BOOL+Configuration.ATTRIBUTES_INT:
            raise AttributeError(f"'Configuration' class has no attribute '{attr}'")
        if attr in Configuration.ATTRIBUTES_STR and not isinstance(value, str):
            raise TypeError(f"'{attr}' must be str, not {type(value).__name__}")
        if attr in Configuration.ATTRIBUTES_BOOL and not isinstance(value, bool):
            raise TypeError(f"'{attr}' must be bool, not {type(value).__name__}")
        if attr in Configuration.ATTRIBUTES_INT and not isinstance(value, int):
            raise TypeError(f"'{attr}' must be int, not {type(value).__name__}")
        if ((attr == "env_os" and value not in ["windows", "linux"]) or # pylint: disable=too-many-boolean-expressions
            (attr == "env_bitness" and value not in [32, 64]) or
            (attr == "env_version" and value not in ["7", "8.1", "10", "11", "22.04.2"]) or
            (attr == "env_type" and value not in ["complete", "clean", "office"]) or
            (attr == "opt_network_geo" and value not in Configuration.OPT_NETWORK_GEO) or
            (attr == "opt_network_residential_proxy_geo" and value not in Configuration.OPT_NETWORK_RESIDENTIAL_PROXY_GEO) or
            (attr == "opt_privacy_type" and value not in ["public", "bylink", "owner", "team"]) or
            (attr == "opt_timeout" and value not in range(10,1201)) or
            (attr == "obj_ext_startfolder" and value not in Configuration.OBJ_EXT_START_FOLDER) or
            (attr == "obj_ext_browser" and value not in ["Google Chrome", "Internet Explorer", "Microsoft Edge", "Mozilla Firefox"])):
            raise ValueError(f"'{attr}' attribute cannot have value of '{value}'")
        # pylint: enable=line-too-long

        if hasattr(self, attr):
            old_value = getattr(self, attr, None)
        else:
            old_value = None
        super().__setattr__(attr, value)
        if self._check_for_conflicts():
            if old_value:
                super().__setattr__(attr, old_value)
            else:
                delattr(self, attr)
            raise ValueError(f"Attribute '{attr}' update to value '{value}' failed: "\
                              "unsupported configuration")

    def _check_for_conflicts(self) -> bool:
        """Checks if provided configuration is supported by ANY.RUN Sandbox API

        This method is called every time a new attribute is being added or
        an existing one is being updated, so there should be no need to call
        it manually
        """
        if (getattr(self, "env_os", None) == "windows" and ( # pylint: disable=too-many-boolean-expressions
                getattr(self, "env_version", None) not in [None, "7", "8.1", "10", "11"] or
                getattr(self, "env_version", None) in ["7", "8.1"] and
                getattr(self, "obj_ext_browser", None) == "Microsoft Edge" or
                hasattr(self, "run_as_root"))
            or
            getattr(self, "env_os", None) == "linux" and (
                getattr(self, "env_bitness", None) == 32 or
                getattr(self, "env_version", None) not in [None, "22.04.2"] or
                getattr(self, "env_type", None) not in [None, "office"] or
                getattr(self, "obj_ext_startfolder", None) not in [None, "desktop", "home", "downloads", "temp"] or # pylint: disable=line-too-long
                getattr(self, "obj_ext_browser", None) not in [None, "Mozilla Firefox", "Google Chrome"] or # pylint: disable=line-too-long
                hasattr(self, "obj_ext_elevateprompt") or
                hasattr(self, "auto_confirm_uac"))
            ):
            return True
        return False

    def __repr__(self) -> str:
        return f"<configuration.object.Object {str(self)}>"

    def get(self,
            attr: str,
            default: typing.Optional[typing.Any] = None
            ) -> typing.Any:
        """Returns an attribute by name.

        If the attribute is not present in the object, it returns None
        or the value specified in the "default" argument.

        :param attr: Name of the attribute.
        :param default: An optional value that will be returned if the
                        attribute is not present in the object.
        :type attr: str
        """
        return self.__dict__.get(attr, default)

    def to_dict(self) -> typing.Dict:
        return self.__dict__.copy()


class TI:
    """Threat Intelligence lookup class for specifying optional parameters
    for the Threat Intelligence lookup request.

    Learn more about available parameters in the ANY.RUN TI Lookup API in:
    https://any.run/api-documentation/
    """

    # pylint: disable=line-too-long
    ATTRIBUTES = ['sha256', 'sha1', 'md5', 'threatname', 'threatlevel', 'tasktype', 'submissioncountry', 'os', 'ossoftwareset', 'osbitversion', 'registrykey', 'registryname', 'registryvalue', 'moduleimagepath', 'rulethreatlevel', 'rulename', 'mitre', 'imagepath', 'commandline', 'injectedflag', 'destinationip', 'destinationport', 'destinationipasn', 'destinationipgeo', 'domainname', 'filename', 'suricataclass', 'suricatamessage', 'suricatathreatlevel', 'suricataid', 'url', 'httprequestcontenttype', 'httpresponsecontenttype', 'httprequestfiletype', 'httpresponsefiletype']
    # pylint: enable=line-too-long

    @classmethod
    def from_dict(cls, attr_dict: typing.Dict):
        """Creates an object from its dictionary representation."""
        if not isinstance(attr_dict, dict):
            raise ValueError(f"Expecting dictionary, got: {type(attr_dict).__name__}")
        return cls(**attr_dict)

    def __init__(self, **kwargs) -> None:
        """Initializes an ANY.RUN TI Lookup API TI object."""
        if kwargs is None:
            raise ValueError("Expecting at least one named argument, got none")
        for attr, value in kwargs.items():
            setattr(self, attr, value)

    def __setattr__(self, attr: str, value: typing.Any) -> None:
        """Sets new attribute value, if all validation checks are successful"""
        if attr not in TI.ATTRIBUTES:
            raise AttributeError(f"'TI' class has no attribute '{attr}'")
        if not isinstance(value, str):
            raise TypeError(f"'{attr}' must be str, not {type(value).__name__}")
        super().__setattr__(attr, value)

    def __repr__(self) -> str:
        return f"<ti.object.Object {str(self)}>"

    def __str__(self) -> str:
        return " AND ".join(f'{attr}:"{value}"' for attr, value in self.__dict__.items())

    def get(self,
            attr: str,
            default: typing.Optional[typing.Any] = None
            ) -> typing.Any:
        """Returns an attribute by name.

        If the attribute is not present in the object, it returns None
        or the value specified in the "default" argument.

        :param attr: Name of the attribute.
        :param default: An optional value that will be returned if the
                        attribute is not present in the object.
        :type attr: str
        """
        return self.__dict__.get(attr, default)
