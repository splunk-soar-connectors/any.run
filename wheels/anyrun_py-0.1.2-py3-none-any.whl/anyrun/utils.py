"""Module defining some helper functions used across the project."""

import asyncio
from typing import Coroutine
from time import sleep

def make_sync(future: Coroutine):
    """Utility function that waits for an async call, making it sync."""
    try:
        event_loop = asyncio.get_event_loop()
    except RuntimeError:
        # Generate an event loop if there isn't any.
        event_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(event_loop)
    return event_loop.run_until_complete(future)

def make_sync_gen(future: Coroutine, time_to_sleep: int = 0):
    """Utility function that waits for an async generator call, making it sync."""
    try:
        event_loop = asyncio.get_event_loop()
    except RuntimeError:
        # Generate an event loop if there isn't any.
        event_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(event_loop)
    while True:
        try:
            yield event_loop.run_until_complete(anext(future))
            if time_to_sleep:
                sleep(time_to_sleep)
        except StopAsyncIteration:
            break
