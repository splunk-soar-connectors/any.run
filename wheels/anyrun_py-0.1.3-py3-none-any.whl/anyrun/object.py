"""Defines a ANY.RUN object and other helper classes."""

from collections import UserDict
import typing
import json


class UserDictJsonEncoder(json.JSONEncoder):
    """Custom json encoder for UserDict objects."""

    def default(self, o):
        if isinstance(o, UserDict):
            return o.data
        return super().default(o)


class Configuration:
    """Analysis configuration class for specifying optional parameters
    for the sandbox, where new submission analysis will be performed.

    Learn more about available parameters in the ANY.RUN Sandbox API in:
    https://any.run/api-documentation/
    """

    # pylint: disable=line-too-long
    ATTRIBUTES_STR = ["env_os", "env_version", "env_type", "env_locale", "opt_network_geo", "opt_network_residential_proxy_geo", "opt_privacy_type", "obj_ext_startfolder", "obj_ext_cmd", "obj_ext_browser", "obj_ext_useragent"]
    ATTRIBUTES_BOOL = ["opt_network_connect", "opt_network_fakenet", "opt_network_tor", "opt_network_mitm", "opt_network_residential_proxy", "opt_automated_interactivity", "obj_ext_elevateprompt", "auto_confirm_uac", "run_as_root", "obj_ext_extension", "opt_privacy_hidesource"]
    ATTRIBUTES_INT = ["env_bitness", "opt_timeout"]

    @classmethod
    def from_dict(cls, attr_dict: typing.Dict):
        """Creates an object from its dictionary representation."""
        if not isinstance(attr_dict, dict):
            raise ValueError(f"Expecting dictionary, got: {type(attr_dict).__name__}")
        return cls(**attr_dict)

    def __init__(self, **kwargs) -> None:
        """Initializes an ANY.RUN Sandbox API Configuration object."""
        if kwargs is None:
            raise ValueError("Expecting at least one named argument, got none")
        for attr, value in kwargs.items():
            setattr(self, attr, value)

    def __setattr__(self, attr: str, value: typing.Any) -> None:
        """Sets new attribute value, if all validation checks are successful"""
        # pylint: disable=line-too-long
        if attr not in Configuration.ATTRIBUTES_STR+Configuration.ATTRIBUTES_BOOL+Configuration.ATTRIBUTES_INT:
            raise AttributeError(f"'Configuration' class has no attribute '{attr}'")
        if attr in Configuration.ATTRIBUTES_STR and not isinstance(value, str):
            raise TypeError(f"'{attr}' must be str, not {type(value).__name__}")
        if attr in Configuration.ATTRIBUTES_BOOL and not isinstance(value, bool):
            raise TypeError(f"'{attr}' must be bool, not {type(value).__name__}")
        if attr in Configuration.ATTRIBUTES_INT and not isinstance(value, int):
            raise TypeError(f"'{attr}' must be int, not {type(value).__name__}")
        super().__setattr__(attr, value)

    def __repr__(self) -> str:
        return f"<configuration.object.Object {str(self)}>"

    def __str__(self) -> str:
        attrs = [attr for attr in Configuration.ATTRIBUTES_STR+Configuration.ATTRIBUTES_BOOL+Configuration.ATTRIBUTES_INT if hasattr(self, attr)] # pylint: disable=line-too-long
        return ", ".join([f"{attr}={getattr(self, attr)}" for attr in attrs])

    def get(self,
            attr: str,
            default: typing.Optional[typing.Any] = None
            ) -> typing.Any:
        """Returns an attribute by name.

        If the attribute is not present in the object, it returns None
        or the value specified in the "default" argument.

        :param attr: Name of the attribute.
        :param default: An optional value that will be returned if the
                        attribute is not present in the object.
        :type attr: str
        """
        return self.__dict__.get(attr, default)

    def to_dict(self) -> typing.Dict:
        return self.__dict__.copy()


class TI:
    """Threat Intelligence lookup class for specifying optional parameters
    for the Threat Intelligence lookup request.

    Learn more about available parameters in the ANY.RUN TI Lookup API in:
    https://any.run/api-documentation/
    """

    # pylint: disable=line-too-long
    ATTRIBUTES = ['sha256', 'sha1', 'md5', 'threatname', 'threatlevel', 'tasktype', 'submissioncountry', 'os', 'ossoftwareset', 'osbitversion', 'registrykey', 'registryname', 'registryvalue', 'moduleimagepath', 'rulethreatlevel', 'rulename', 'mitre', 'imagepath', 'commandline', 'injectedflag', 'destinationip', 'destinationport', 'destinationipasn', 'destinationipgeo', 'ja3', 'ja3s', 'jarm', 'domainname', 'filename', 'filepath', 'fileeventname', 'fileeventpath', 'fileextension', 'syncobjectname', 'syncobjecttype', 'syncobjectoperation', 'suricataclass', 'suricatamessage', 'suricatathreatlevel', 'suricataid', 'url', 'httprequestcontenttype', 'httpresponsecontenttype', 'httprequestfiletype', 'httpresponsefiletype']
    # pylint: enable=line-too-long

    @classmethod
    def from_dict(cls, attr_dict: typing.Dict):
        """Creates an object from its dictionary representation."""
        if not isinstance(attr_dict, dict):
            raise ValueError(f"Expecting dictionary, got: {type(attr_dict).__name__}")
        return cls(**attr_dict)

    def __init__(self, **kwargs) -> None:
        """Initializes an ANY.RUN TI Lookup API TI object."""
        if kwargs is None:
            raise ValueError("Expecting at least one named argument, got none")
        for attr, value in kwargs.items():
            setattr(self, attr, value)

    def __setattr__(self, attr: str, value: typing.Any) -> None:
        """Sets new attribute value, if all validation checks are successful"""
        if attr not in TI.ATTRIBUTES:
            raise AttributeError(f"'TI' class has no attribute '{attr}'")
        if not isinstance(value, str):
            raise TypeError(f"'{attr}' must be str, not {type(value).__name__}")
        super().__setattr__(attr, value)

    def __repr__(self) -> str:
        return f"<ti.object.Object {str(self)}>"

    def __str__(self) -> str:
        return " AND ".join(f'{attr}:"{value}"' for attr, value in self.__dict__.items())

    def get(self,
            attr: str,
            default: typing.Optional[typing.Any] = None
            ) -> typing.Any:
        """Returns an attribute by name.

        If the attribute is not present in the object, it returns None
        or the value specified in the "default" argument.

        :param attr: Name of the attribute.
        :param default: An optional value that will be returned if the
                        attribute is not present in the object.
        :type attr: str
        """
        return self.__dict__.get(attr, default)
