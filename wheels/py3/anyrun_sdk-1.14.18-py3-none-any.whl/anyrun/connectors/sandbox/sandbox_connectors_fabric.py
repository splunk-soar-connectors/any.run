from typing import Optional

import aiohttp

from anyrun.utils.config import Config
from anyrun.connectors.sandbox.operation_systems import (
    WindowsConnector,
    AndroidConnector,
    LinuxConnector,
    MacOSConnector
)


class SandboxConnector:
    """ Connectors Factory. Creates a concrete connector instance according to the method called """
    @staticmethod
    def windows(
        api_key: str,
        integration: str = Config.PUBLIC_INTEGRATION,
        trust_env: bool = False,
        verify_ssl: Optional[str] = None,
        proxy: Optional[str] = None,
        proxy_username: Optional[str] = None,
        proxy_password: Optional[str] = None,
        connector: Optional[aiohttp.BaseConnector] = None,
        timeout: int = Config.DEFAULT_REQUEST_TIMEOUT_IN_SECONDS,
        enable_requests: bool = False,
        root_url: Optional[str] = Config.DEFAULT_ROOT_URL
    ) -> WindowsConnector:
        """
        :param api_key: ANY.RUN API-KEY without a prefix.
        :param integration: Name of the integration.
        :param trust_env: Trust environment settings for proxy configuration.
        :param verify_ssl: Enable/disable SSL verification option.
        :param proxy: Proxy url. Example: http://<host>:<port>.
        :param proxy_username: Proxy username.
        :param proxy_password: Proxy password.
        :param connector: A custom aiohttp connector.
        :param timeout: Override the session’s timeout.
        :param enable_requests: Use requests.request to make api calls. May block the event loop.
        :param root_url: Root url.
        """
        return WindowsConnector(
            api_key=api_key,
            integration=integration,
            trust_env=trust_env,
            verify_ssl=verify_ssl,
            proxy=proxy,
            proxy_username=proxy_username,
            proxy_password=proxy_password,
            connector=connector,
            timeout=timeout,
            enable_requests=enable_requests,
            root_url=root_url
        )

    @staticmethod
    def linux(
        api_key: str,
        integration: str = Config.PUBLIC_INTEGRATION,
        trust_env: bool = False,
        verify_ssl: Optional[str] = None,
        proxy: Optional[str] = None,
        proxy_username: Optional[str] = None,
        proxy_password: Optional[str] = None,
        connector: Optional[aiohttp.BaseConnector] = None,
        timeout: int = Config.DEFAULT_REQUEST_TIMEOUT_IN_SECONDS,
        enable_requests: bool = False,
        root_url: Optional[str] = Config.DEFAULT_ROOT_URL
    ) -> LinuxConnector:
        """
        :param api_key: ANY.RUN API-KEY without a prefix.
        :param integration: Name of the integration.
        :param trust_env: Trust environment settings for proxy configuration.
        :param verify_ssl: Enable/disable SSL verification option.
        :param proxy: Proxy url. Example: https://<host>:<port>.
        :param proxy_username: Proxy username.
        :param proxy_password: Proxy password.
        :param connector: A custom aiohttp connector.
        :param timeout: Override the session’s timeout.
        :param enable_requests: Use requests.request to make api calls. May block the event loop.
        :param root_url: Root URL for the API.
        """
        return LinuxConnector(
            api_key=api_key,
            integration=integration,
            trust_env=trust_env,
            verify_ssl=verify_ssl,
            proxy=proxy,
            proxy_username=proxy_username,
            proxy_password=proxy_password,
            connector=connector,
            timeout=timeout,
            enable_requests=enable_requests,
            root_url=root_url
        )

    @staticmethod
    def android(
        api_key: str,
        integration: str = Config.PUBLIC_INTEGRATION,
        trust_env: bool = False,
        verify_ssl: Optional[str] = None,
        proxy: Optional[str] = None,
        proxy_username: Optional[str] = None,
        proxy_password: Optional[str] = None,
        connector: Optional[aiohttp.BaseConnector] = None,
        timeout: int = Config.DEFAULT_REQUEST_TIMEOUT_IN_SECONDS,
        enable_requests: bool = False,
        root_url: Optional[str] = Config.DEFAULT_ROOT_URL
    ) -> AndroidConnector:
        """
        :param api_key: ANY.RUN API-KEY without a prefix.
        :param integration: Name of the integration.
        :param trust_env: Trust environment settings for proxy configuration.
        :param verify_ssl: Enable/disable SSL verification option.
        :param proxy: Proxy url. Example: http://<host>:<port>.
        :param proxy_username: Proxy username.
        :param proxy_password: Proxy password.
        :param connector: A custom aiohttp connector.
        :param timeout: Override the session’s timeout.
        :param enable_requests: Use requests.request to make api calls. May block the event loop.
        :param root_url: Root URL for the API.
        """
        return AndroidConnector(
            api_key=api_key,
            integration=integration,
            trust_env=trust_env,
            verify_ssl=verify_ssl,
            proxy=proxy,
            proxy_username=proxy_username,
            proxy_password=proxy_password,
            connector=connector,
            timeout=timeout,
            enable_requests=enable_requests,
            root_url=root_url
        )

    @staticmethod
    def macos(
        api_key: str,
        integration: str = Config.PUBLIC_INTEGRATION,
        trust_env: bool = False,
        verify_ssl: Optional[str] = None,
        proxy: Optional[str] = None,
        proxy_username: Optional[str] = None,
        proxy_password: Optional[str] = None,
        connector: Optional[aiohttp.BaseConnector] = None,
        timeout: int = Config.DEFAULT_REQUEST_TIMEOUT_IN_SECONDS,
        enable_requests: bool = False,
        root_url: Optional[str] = Config.DEFAULT_ROOT_URL
    ) -> MacOSConnector:
        """
        :param api_key: ANY.RUN API-KEY without a prefix.
        :param integration: Name of the integration.
        :param trust_env: Trust environment settings for proxy configuration.
        :param verify_ssl: Enable/disable SSL verification option.
        :param proxy: Proxy url. Example: https://<host>:<port>.
        :param proxy_username: Proxy username.
        :param proxy_password: Proxy password.
        :param connector: A custom aiohttp connector.
        :param timeout: Override the session’s timeout.
        :param enable_requests: Use requests.request to make api calls. May block the event loop.
        :param root_url: Root URL for the API.
        """
        return MacOSConnector(
            api_key=api_key,
            integration=integration,
            trust_env=trust_env,
            verify_ssl=verify_ssl,
            proxy=proxy,
            proxy_username=proxy_username,
            proxy_password=proxy_password,
            connector=connector,
            timeout=timeout,
            enable_requests=enable_requests,
            root_url=root_url
        )

