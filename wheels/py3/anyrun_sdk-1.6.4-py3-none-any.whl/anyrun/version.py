"""Defines ANY.RUN release version."""

__version__ = '1.6.4'
