# Test cases for ebcdic package.
